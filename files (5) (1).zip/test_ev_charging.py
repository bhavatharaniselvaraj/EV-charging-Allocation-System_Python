"""Tests for the EV charging system. Run:  python test_ev_charging.py"""
import io
import random
import unittest
from contextlib import redirect_stdout
from unittest import mock

import ev_charging_system as ev
from ev_charging_system import (ChargingSystem, ConflictError, IntervalTree,
                                AdminSession, parse_time as t)


def make_system():
    s = ChargingSystem()
    s.add_station("S1", "One", "Loc1", 50)
    s.add_station("S2", "Two", "Loc2", 50)
    s.add_station("S3", "Three", "Loc3", 50)
    return s


class TestIntervalTree(unittest.TestCase):
    def test_max_end_and_overlap(self):
        tree = IntervalTree()
        tree.insert("A", "E1", 600, 660)
        tree.insert("B", "E2", 700, 800)
        tree.insert("C", "E3", 500, 550)
        self.assertTrue(tree.is_valid())
        self.assertEqual(tree.root.max_end_time, 800)
        self.assertTrue(tree.has_overlap(650, 710))
        self.assertFalse(tree.has_overlap(660, 700))     # adjacent -> free (half-open)

    def test_duplicate_intervals_distinct_ids(self):
        tree = IntervalTree()
        tree.insert("A", "E1", 600, 660)
        tree.insert("B", "E2", 600, 660)
        self.assertEqual(tree.size, 2)
        self.assertTrue(tree.delete("A", 600, 660))
        self.assertIsNotNone(tree.find_by_id("B"))
        self.assertIsNone(tree.find_by_id("A"))
        self.assertTrue(tree.is_valid())

    def test_random_against_brute_force(self):
        rnd = random.Random(1)
        tree, items = IntervalTree(), {}
        for i in range(300):
            s = rnd.randint(0, 1400)
            e = s + rnd.randint(1, 40)
            tree.insert(f"R{i}", "E", s, e)
            items[f"R{i}"] = (s, e)
        for rid in rnd.sample(list(items), 120):
            self.assertTrue(tree.delete(rid, *items.pop(rid)))
            self.assertTrue(tree.is_valid())
        for _ in range(300):
            s = rnd.randint(0, 1400)
            e = s + rnd.randint(1, 60)
            expected = {r for r, (a, b) in items.items() if a < e and s < b}
            got = {n.reservation_id for n in tree.find_all_overlaps(s, e)}
            self.assertEqual(got, expected)
            self.assertEqual(tree.has_overlap(s, e), bool(expected))


class TestSystem(unittest.TestCase):
    def setUp(self):
        self.s = make_system()

    def test_01_add_station(self):
        self.s.add_station("S4", "Four", "L4", 22)
        self.assertIn("S4", self.s.stations)
        self.assertEqual(self.s.stations["S4"].tree.size, 0)

    def test_02_duplicate_station(self):
        with self.assertRaises(ValueError):
            self.s.add_station("s1", "X", "Y", 10)

    def test_03_delete_empty_station(self):
        self.s.add_station("S4", "Four", "L4", 22)
        self.s.delete_station("S2")
        self.assertNotIn("S2", self.s.stations)
        self.assertEqual(len(self.s.stations), 3)

    def test_04_unsafe_delete_blocked(self):
        self.s.add_station("S4", "Four", "L4", 22)
        self.s.book("EV1", "S1", t("09:00"), t("10:00"), t("08:00"))
        with self.assertRaises(ValueError):
            self.s.delete_station("S1")
        self.assertIn("S1", self.s.stations)
        self.assertEqual(len(self.s.reservations), 1)

    def test_04b_delete_with_relocate_and_waitlist(self):
        self.s.add_station("S4", "Four", "L4", 22)
        self.s.book("EV1", "S1", t("09:00"), t("10:00"), t("08:00"))
        self.s.book("EV2", "S1", t("11:00"), t("12:00"), t("08:00"))
        for sid in ("S2", "S3", "S4"):                                   # block EV2's relocation
            self.s.book("EVX" + sid, sid, t("11:00"), t("12:00"), t("08:00"))
        summary = self.s.delete_station("S1", "relocate")
        self.assertEqual(len(summary["moved"]), 1)
        self.assertEqual(len(summary["waitlisted"]), 1)
        self.assertEqual(len(self.s.waiting), 1)
        self.assertTrue(self.s.verify_consistency())

    def test_04c_delete_with_cancel(self):
        self.s.add_station("S4", "Four", "L4", 22)
        self.s.book("EV1", "S1", t("09:00"), t("10:00"), t("08:00"))
        summary = self.s.delete_station("S1", "cancel")
        self.assertEqual(len(summary["cancelled"]), 1)
        self.assertEqual(self.s.reservations, {})

    def test_no_minimum_station_rule(self):
        s = ChargingSystem()
        s.add_station("S1", "One", "L1", 50)
        s.book("EV1", "S1", t("10:00"), t("11:00"), t("09:00"))     # works with 1 station
        s.delete_station("S1", "cancel")                              # deletable too
        self.assertEqual(s.stations, {})

    def test_ev_id_must_be_unique(self):
        self.s.book("EV1", "S1", t("10:00"), t("11:00"), t("09:00"))
        with self.assertRaises(ValueError):
            self.s.book("ev1", "S2", t("12:00"), t("13:00"), t("11:00"))
        with self.assertRaises(ValueError):
            self.s.add_waiting("EV1", None, t("12:00"), t("13:00"), t("11:00"))
        self.s.add_waiting("EV2", None, t("10:00"), t("11:00"), t("09:00"))
        with self.assertRaises(ValueError):
            self.s.book("EV2", "S3", t("10:00"), t("11:00"), t("09:00"))
        # ID becomes free again once the reservation is cancelled
        self.s.cancel("R001")                      # EV2 gets the freed slot automatically
        self.s.book("EV1", "S3", t("12:00"), t("13:00"), t("11:00"))

    def test_05_06_07_booking_overlap_adjacent(self):
        r = self.s.book("EV1", "S1", t("10:00"), t("11:00"), t("09:45"))
        self.assertEqual(r.reservation_id, "R001")
        with self.assertRaises(ConflictError):
            self.s.book("EV2", "S1", t("10:30"), t("11:30"), t("10:00"))
        self.s.book("EV3", "S1", t("11:00"), t("12:00"), t("10:50"))       # adjacent OK
        self.s.book("EV4", "S1", t("09:00"), t("10:00"), t("08:50"))       # adjacent before OK
        self.assertTrue(self.s.verify_consistency())

    def test_invalid_booking_input(self):
        with self.assertRaises(ValueError):
            self.s.book("EV1", "S1", t("11:00"), t("10:00"), t("09:00"))
        with self.assertRaises(ValueError):
            self.s.book("EV1", "S9", t("10:00"), t("11:00"), t("09:00"))
        with self.assertRaises(ValueError):
            ev.parse_time("25:99")
        with self.assertRaises(ValueError):
            ev.parse_time("abc")

    def test_08_alternative_station(self):
        self.s.book("EV1", "S1", t("10:00"), t("11:00"), t("09:00"))
        self.assertEqual(self.s.free_stations(t("10:00"), t("11:00"), exclude="S1"), ["S2", "S3"])

    def test_09_alternative_time(self):
        self.s.book("EV1", "S1", t("10:00"), t("11:00"), t("09:00"))
        self.s.book("EV2", "S2", t("10:00"), t("11:00"), t("09:00"))
        slots = self.s.suggest_time_slots(["S1", "S2"], t("10:00"), t("11:00"))
        self.assertTrue(slots)
        for sid, a, b in slots:
            self.assertTrue(self.s.is_free(sid, a, b))
            self.assertEqual(b - a, 60)

    def test_10_11_12_waiting_and_allocation(self):
        r1 = self.s.book("EV1", "S1", t("10:00"), t("11:00"), t("09:00"))
        self.s.book("EV2", "S2", t("10:00"), t("11:00"), t("09:00"))
        self.s.book("EV3", "S3", t("10:00"), t("11:00"), t("09:00"))
        self.s.add_waiting("EV9", ["S1"], t("10:00"), t("11:00"), t("09:30"))
        self.assertEqual(len(self.s.waiting), 1)
        cancelled, allocated = self.s.cancel(r1.reservation_id)
        self.assertEqual(cancelled.ev_id, "EV1")
        self.assertEqual(len(allocated), 1)
        self.assertEqual(allocated[0].ev_id, "EV9")
        self.assertEqual(self.s.waiting, [])
        self.assertTrue(self.s.verify_consistency())

    def test_waiting_not_allocated_if_station_not_preferred(self):
        r1 = self.s.book("EV1", "S1", t("10:00"), t("11:00"), t("09:00"))
        self.s.add_waiting("EV9", ["S2"], t("10:00"), t("11:00"), t("09:30"))
        _, allocated = self.s.cancel(r1.reservation_id)
        self.assertEqual(allocated, [])
        self.assertEqual(len(self.s.waiting), 1)

    def test_13_update_success_frees_old_slot(self):
        r = self.s.book("EV1", "S1", t("10:00"), t("11:00"), t("09:00"))
        self.s.update(r.reservation_id, "S1", t("10:30"), t("11:30"))   # overlaps its own old slot
        self.assertEqual((r.start, r.end), (t("10:30"), t("11:30")))
        self.assertTrue(self.s.is_free("S1", t("10:00"), t("10:30")))
        self.assertTrue(self.s.verify_consistency())

    def test_14_conflicting_update_keeps_original(self):
        r = self.s.book("EV1", "S1", t("10:00"), t("11:00"), t("09:00"))
        self.s.book("EV2", "S1", t("12:00"), t("13:00"), t("09:00"))
        with self.assertRaises(ConflictError):
            self.s.update(r.reservation_id, "S1", t("12:30"), t("13:30"))
        self.assertEqual((r.station_id, r.start, r.end), ("S1", t("10:00"), t("11:00")))
        self.assertFalse(self.s.is_free("S1", t("10:00"), t("11:00")))
        self.assertTrue(self.s.verify_consistency())

    def test_update_move_station(self):
        r = self.s.book("EV1", "S1", t("10:00"), t("11:00"), t("09:00"))
        self.s.update(r.reservation_id, "S2", t("10:00"), t("11:00"))
        self.assertTrue(self.s.is_free("S1", t("10:00"), t("11:00")))
        self.assertFalse(self.s.is_free("S2", t("10:00"), t("11:00")))
        self.assertTrue(self.s.verify_consistency())

    def test_15_service_time(self):
        self.assertEqual(ev.service_time(t("10:00"), t("11:30")), 90)

    def test_16_waiting_time(self):
        self.assertEqual(ev.waiting_time(t("09:45"), t("10:00")), 15)
        with self.assertRaises(ValueError):
            ev.waiting_time(t("10:00"), t("09:00"))

    def test_17_18_traversal_and_search(self):
        self.s.book("EV1", "S1", t("12:00"), t("13:00"), t("11:00"))
        self.s.book("EV2", "S1", t("08:00"), t("09:00"), t("07:00"))
        self.s.book("EV3", "S1", t("10:00"), t("11:00"), t("09:00"))
        starts = [r.start for r in self.s.all_reservations("S1")]
        self.assertEqual(starts, sorted(starts))
        self.assertEqual(self.s.find_by_id("r002").ev_id, "EV2")
        self.assertEqual(len(self.s.find_by_ev("ev3")), 1)
        self.assertIsNone(self.s.find_by_id("R999"))

    def test_21_empty_cases(self):
        empty = ChargingSystem()
        self.assertEqual(empty.all_reservations(), [])
        self.assertEqual(empty.process_waiting(), [])
        self.assertEqual(self.s.all_reservations("S1"), [])
        with self.assertRaises(ValueError):
            self.s.cancel("R404")
        with self.assertRaises(ValueError):
            self.s.update("R404", "S1", 600, 660)
        with self.assertRaises(ValueError):
            self.s.get_station("NOPE")


class TestAdminAccess(unittest.TestCase):
    def test_19_wrong_key_rejected(self):
        session = AdminSession()
        self.assertFalse(session.login("wrong"))
        with self.assertRaises(PermissionError):
            session.require()
        self.assertTrue(session.login(ev.ADMIN_SECRET_KEY))
        session.logout()
        with self.assertRaises(PermissionError):
            session.require()

    def test_admin_function_needs_session(self):
        with self.assertRaises(PermissionError):
            ev.admin_add_station(ChargingSystem(), AdminSession())

    def test_19_menu_denies_wrong_key(self):
        out = io.StringIO()
        with mock.patch("ev_charging_system.read_secret", return_value="bad"), redirect_stdout(out):
            ev.admin_menu(ChargingSystem())
        self.assertIn("Access denied", out.getvalue())
        self.assertNotIn("ADMIN MENU", out.getvalue())

    def test_20_user_menu_has_no_admin_actions(self):
        out = io.StringIO()
        inputs = iter(["99", "1", "9"])
        with mock.patch("builtins.input", lambda _="": next(inputs)), redirect_stdout(out):
            ev.user_menu(ChargingSystem())
        text = out.getvalue()
        self.assertNotIn("ADMIN MENU", text)
        self.assertNotIn("Add Charging Station", text)
        self.assertIn("Invalid option", text)

    def test_user_cannot_cancel_other_users_reservation(self):
        s = make_system()
        r = s.book("EV1", "S1", t("10:00"), t("11:00"), t("09:00"))
        inputs = iter(["EV2", r.reservation_id])
        out = io.StringIO()
        with mock.patch("builtins.input", lambda _="": next(inputs)), redirect_stdout(out):
            ev.user_cancel(s)
        self.assertIn("No such reservation", out.getvalue())
        self.assertIn(r.reservation_id, s.reservations)


def run_input(func, system, answers):
    inputs = iter(answers)
    out = io.StringIO()
    with mock.patch("builtins.input", lambda _="": next(inputs)), redirect_stdout(out):
        func(system)
    return out.getvalue()


class TestScriptedSession(unittest.TestCase):
    def test_redirect_with_permission(self):
        s = make_system()
        s.book("EV1", "S1", t("10:00"), t("11:00"), t("09:00"))
        # EV2 wants S1 10:30-11:30 -> conflict -> says YES to redirect -> picks #1 (S2)
        text = run_input(ev.user_book, s, ["EV2", "S1", "10:00", "10:30", "11:30", "y", "1"])
        self.assertIn("RESERVATION CONFIRMED", text)
        self.assertEqual(s.find_by_ev("EV2")[0].station_id, "S2")
        self.assertEqual(s.waiting, [])

    def test_redirect_declined_goes_to_waiting_list(self):
        s = make_system()
        s.book("EV1", "S1", t("10:00"), t("11:00"), t("09:00"))
        # other stations are free, but the user says NO -> waiting list (S1 only)
        text = run_input(ev.user_book, s, ["EV2", "S1", "10:00", "10:30", "11:30", "n"])
        self.assertIn("WAITING LIST", text)
        self.assertEqual(s.find_by_ev("EV2"), [])           # never moved without permission
        self.assertEqual(len(s.waiting), 1)
        self.assertEqual(s.waiting[0].stations, ["S1"])

    def test_no_free_station_goes_to_waiting_list(self):
        s = make_system()
        for sid in ("S1", "S2", "S3"):
            s.book("EV" + sid, sid, 0, 1440, 0)             # whole day booked everywhere
        text = run_input(ev.user_book, s, ["EV9", "S1", "09:00", "10:00", "11:00"])
        self.assertIn("WAITING LIST", text)
        self.assertEqual(len(s.waiting), 1)
        self.assertIsNone(s.waiting[0].stations)            # any station

    def test_user_book_reprompts_for_taken_ev_id(self):
        s = make_system()
        s.book("EV1", "S1", t("10:00"), t("11:00"), t("09:00"))
        text = run_input(ev.user_book, s, ["EV1", "EV2", "S2", "09:00", "10:00", "11:00"])
        self.assertIn("already taken", text)
        self.assertIn("Service time", text)          # shown automatically on booking
        self.assertEqual(len(s.find_by_ev("EV2")), 1)

    def test_menu_has_no_service_time_option_or_empty_tree_message(self):
        out = io.StringIO()
        inputs = iter(["9"])
        with mock.patch("builtins.input", lambda _="": next(inputs)), redirect_stdout(out):
            ev.user_menu(ChargingSystem())
        self.assertNotIn("Calculate Service Time", out.getvalue())
        self.assertNotIn("Interval Tree", out.getvalue())
        for hidden in ("Find Alternative Station", "Find Alternative Time Slot", "Join Waiting List"):
            self.assertNotIn(hidden, out.getvalue())
        for fn in ("user_find_alt_station", "user_find_alt_time", "user_join_waiting"):
            self.assertTrue(callable(getattr(ev, fn)))      # functions still exist

    def test_waiting_entry_allocated_after_cancel(self):
        s = make_system()
        r = s.book("EV1", "S1", t("10:00"), t("11:00"), t("09:00"))
        run_input(ev.user_book, s, ["EV2", "S1", "10:00", "10:00", "11:00", "n"])
        _, allocated = s.cancel(r.reservation_id)
        self.assertEqual([a.ev_id for a in allocated], ["EV2"])

    def test_leave_waiting_list(self):
        s = make_system()
        s.add_waiting("EV5", None, t("10:00"), t("11:00"), t("09:00"))
        run_input(ev.user_leave_waiting, s, ["EV5", "1"])
        self.assertEqual(s.waiting, [])


if __name__ == "__main__":
    unittest.main(verbosity=1)
